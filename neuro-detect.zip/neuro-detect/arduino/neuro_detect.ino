// ============================================================
//  NEURO DETECT - ESP32 Tremor Detection System
//  Hardware: ESP32 Dev Module + MPU6050
//  SDA = GPIO21 | SCL = GPIO22
//  Protocol: I2C (sensor) + WiFi + HTTP JSON (dashboard)
// ============================================================

#include <Wire.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>

// ─────────────────────────────────────────────
//  WIFI CREDENTIALS  →  Change these!
// ─────────────────────────────────────────────
const char* WIFI_SSID     = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

// ─────────────────────────────────────────────
//  TREMOR DETECTION THRESHOLDS
//  Adjust these if false positives occur
// ─────────────────────────────────────────────
const float TREMOR_GYRO_THRESHOLD   = 0.30f;  // rad/s  – minimum gyro magnitude to flag
const float TREMOR_MILD_THRESHOLD   = 0.50f;  // rad/s  – mild tremor
const float TREMOR_MODERATE_THRESHOLD = 1.00f;// rad/s  – moderate tremor
const float TREMOR_SEVERE_THRESHOLD = 2.00f;  // rad/s  – severe tremor
const int   SMOOTHING_SAMPLES       = 10;     // moving-average window size
const int   TREMOR_CONFIRM_COUNT    = 5;      // consecutive readings needed to confirm tremor
const unsigned long SAMPLE_INTERVAL_MS = 20;  // 50 Hz sampling rate

// ─────────────────────────────────────────────
//  CALIBRATION
// ─────────────────────────────────────────────
const int CALIB_SAMPLES = 200;     // samples collected during calibration
float gyroOffsetX = 0, gyroOffsetY = 0, gyroOffsetZ = 0;
float accelOffsetX = 0, accelOffsetY = 0, accelOffsetZ = 0;

// ─────────────────────────────────────────────
//  MOVING-AVERAGE FILTER BUFFERS
// ─────────────────────────────────────────────
float gxBuf[SMOOTHING_SAMPLES] = {0};
float gyBuf[SMOOTHING_SAMPLES] = {0};
float gzBuf[SMOOTHING_SAMPLES] = {0};
float axBuf[SMOOTHING_SAMPLES] = {0};
float ayBuf[SMOOTHING_SAMPLES] = {0};
float azBuf[SMOOTHING_SAMPLES] = {0};
int   bufIndex = 0;

// ─────────────────────────────────────────────
//  SENSOR & SERVER OBJECTS
// ─────────────────────────────────────────────
Adafruit_MPU6050 mpu;
WebServer server(80);

// ─────────────────────────────────────────────
//  GLOBAL STATE
// ─────────────────────────────────────────────
float smoothGX = 0, smoothGY = 0, smoothGZ = 0;
float smoothAX = 0, smoothAY = 0, smoothAZ = 0;
float gyroMagnitude  = 0;
float motionLevel    = 0;
bool  tremorDetected = false;
String tremorIntensity = "NONE";
int   tremorConfirmCounter = 0;
unsigned long lastSampleTime = 0;
unsigned long lastPrintTime  = 0;

// ─────────────────────────────────────────────
//  FUNCTION PROTOTYPES
// ─────────────────────────────────────────────
void connectWiFi();
void calibrateSensor();
void readAndFilter();
void detectTremor();
void handleRoot();
void handleData();
void handleCORS();
void printSerial();
String buildJSON();

// ════════════════════════════════════════════
//  SETUP
// ════════════════════════════════════════════
void setup() {
  Serial.begin(115200);
  delay(500);

  Serial.println();
  Serial.println("╔══════════════════════════════════╗");
  Serial.println("║     NEURO DETECT  v1.0           ║");
  Serial.println("║  ESP32 Tremor Detection System   ║");
  Serial.println("╚══════════════════════════════════╝");
  Serial.println();

  // ── Initialize I2C and MPU6050 ──────────────
  Wire.begin(21, 22);   // SDA=21, SCL=22
  Serial.print("[SENSOR] Initializing MPU6050... ");

  if (!mpu.begin()) {
    Serial.println("FAILED!");
    Serial.println("[SENSOR] MPU6050 not detected. Check wiring:");
    Serial.println("         VCC → 3.3V");
    Serial.println("         GND → GND");
    Serial.println("         SDA → GPIO21");
    Serial.println("         SCL → GPIO22");
    Serial.println("[SYSTEM] Halting. Please fix wiring and restart.");
    while (true) { delay(1000); }
  }
  Serial.println("OK");

  // ── Sensor Configuration ─────────────────────
  mpu.setAccelerometerRange(MPU6050_RANGE_4_G);
  mpu.setGyroRange(MPU6050_RANGE_500_DEG);
  mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);
  Serial.println("[SENSOR] Configured: Accel ±4g | Gyro ±500°/s | LPF 21Hz");

  // ── Calibration ──────────────────────────────
  calibrateSensor();

  // ── WiFi Connection ───────────────────────────
  connectWiFi();

  // ── HTTP Routes ───────────────────────────────
  server.on("/",        HTTP_GET, handleRoot);
  server.on("/data",    HTTP_GET, handleData);
  server.on("/data",    HTTP_OPTIONS, handleCORS);
  server.begin();

  Serial.println();
  Serial.println("[SERVER] HTTP server started.");
  Serial.print  ("[SERVER] Dashboard URL: http://");
  Serial.println(WiFi.localIP());
  Serial.println("[SYSTEM] Ready. Starting tremor monitoring...");
  Serial.println("─────────────────────────────────────────────");
}

// ════════════════════════════════════════════
//  LOOP
// ════════════════════════════════════════════
void loop() {
  server.handleClient();   // Handle any incoming HTTP requests

  unsigned long now = millis();
  if (now - lastSampleTime >= SAMPLE_INTERVAL_MS) {
    lastSampleTime = now;
    readAndFilter();
    detectTremor();
  }

  if (now - lastPrintTime >= 500) {   // Print every 500ms
    lastPrintTime = now;
    printSerial();
  }
}

// ════════════════════════════════════════════
//  WIFI CONNECTION
// ════════════════════════════════════════════
void connectWiFi() {
  Serial.print("[WIFI]  Connecting to: ");
  Serial.println(WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 30) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println();
    Serial.print("[WIFI]  Connected! IP: ");
    Serial.println(WiFi.localIP());
    Serial.print("[WIFI]  Signal strength (RSSI): ");
    Serial.print(WiFi.RSSI());
    Serial.println(" dBm");
  } else {
    Serial.println();
    Serial.println("[WIFI]  Connection FAILED. Check SSID/Password.");
    Serial.println("[SYSTEM] Continuing without WiFi (sensor-only mode).");
  }
}

// ════════════════════════════════════════════
//  SENSOR CALIBRATION
// ════════════════════════════════════════════
void calibrateSensor() {
  Serial.println();
  Serial.println("[CALIB] ── Starting Calibration ──────────────");
  Serial.println("[CALIB] Keep the sensor PERFECTLY STILL...");
  delay(2000);   // Give user time to set device down

  double sumGX = 0, sumGY = 0, sumGZ = 0;
  double sumAX = 0, sumAY = 0, sumAZ = 0;

  for (int i = 0; i < CALIB_SAMPLES; i++) {
    sensors_event_t accel, gyro, temp;
    mpu.getEvent(&accel, &gyro, &temp);

    sumGX += gyro.gyro.x;
    sumGY += gyro.gyro.y;
    sumGZ += gyro.gyro.z;
    sumAX += accel.acceleration.x;
    sumAY += accel.acceleration.y;
    sumAZ += (accel.acceleration.z - 9.81f);  // Remove gravity from Z

    if (i % 40 == 0) {
      Serial.print("[CALIB] Progress: ");
      Serial.print((i * 100) / CALIB_SAMPLES);
      Serial.println("%");
    }
    delay(10);
  }

  gyroOffsetX = sumGX / CALIB_SAMPLES;
  gyroOffsetY = sumGY / CALIB_SAMPLES;
  gyroOffsetZ = sumGZ / CALIB_SAMPLES;
  accelOffsetX = sumAX / CALIB_SAMPLES;
  accelOffsetY = sumAY / CALIB_SAMPLES;
  accelOffsetZ = sumAZ / CALIB_SAMPLES;

  Serial.println("[CALIB] Progress: 100% — Done!");
  Serial.println("[CALIB] Offsets calculated:");
  Serial.print  ("[CALIB]   Gyro  X="); Serial.print(gyroOffsetX, 4);
  Serial.print  ("  Y=");               Serial.print(gyroOffsetY, 4);
  Serial.print  ("  Z=");               Serial.println(gyroOffsetZ, 4);
  Serial.print  ("[CALIB]   Accel X="); Serial.print(accelOffsetX, 4);
  Serial.print  ("  Y=");               Serial.print(accelOffsetY, 4);
  Serial.print  ("  Z=");               Serial.println(accelOffsetZ, 4);
  Serial.println("[CALIB] ── Calibration Complete ─────────────");
  Serial.println();
}

// ════════════════════════════════════════════
//  READ SENSOR + APPLY MOVING-AVERAGE FILTER
// ════════════════════════════════════════════
void readAndFilter() {
  sensors_event_t accel, gyro, temp;
  mpu.getEvent(&accel, &gyro, &temp);

  // Apply calibration offsets
  float gx = gyro.gyro.x  - gyroOffsetX;
  float gy = gyro.gyro.y  - gyroOffsetY;
  float gz = gyro.gyro.z  - gyroOffsetZ;
  float ax = accel.acceleration.x - accelOffsetX;
  float ay = accel.acceleration.y - accelOffsetY;
  float az = accel.acceleration.z - accelOffsetZ;

  // Store into circular buffer
  gxBuf[bufIndex] = gx;
  gyBuf[bufIndex] = gy;
  gzBuf[bufIndex] = gz;
  axBuf[bufIndex] = ax;
  ayBuf[bufIndex] = ay;
  azBuf[bufIndex] = az;
  bufIndex = (bufIndex + 1) % SMOOTHING_SAMPLES;

  // Compute moving averages
  float sgx = 0, sgy = 0, sgz = 0;
  float sax = 0, say = 0, saz = 0;
  for (int i = 0; i < SMOOTHING_SAMPLES; i++) {
    sgx += gxBuf[i]; sgy += gyBuf[i]; sgz += gzBuf[i];
    sax += axBuf[i]; say += ayBuf[i]; saz += azBuf[i];
  }
  smoothGX = sgx / SMOOTHING_SAMPLES;
  smoothGY = sgy / SMOOTHING_SAMPLES;
  smoothGZ = sgz / SMOOTHING_SAMPLES;
  smoothAX = sax / SMOOTHING_SAMPLES;
  smoothAY = say / SMOOTHING_SAMPLES;
  smoothAZ = saz / SMOOTHING_SAMPLES;

  // Gyro magnitude (overall rotational speed)
  gyroMagnitude = sqrt(smoothGX*smoothGX + smoothGY*smoothGY + smoothGZ*smoothGZ);

  // Motion level (combined gyro + accel deviation)
  float accelMag = sqrt(smoothAX*smoothAX + smoothAY*smoothAY + smoothAZ*smoothAZ);
  motionLevel = (gyroMagnitude * 0.7f) + (accelMag * 0.3f);
}

// ════════════════════════════════════════════
//  TREMOR DETECTION LOGIC
// ════════════════════════════════════════════
void detectTremor() {
  bool instantTremor = (gyroMagnitude > TREMOR_GYRO_THRESHOLD);

  // Require N consecutive detections to confirm (debounce)
  if (instantTremor) {
    tremorConfirmCounter = min(tremorConfirmCounter + 1, TREMOR_CONFIRM_COUNT + 2);
  } else {
    tremorConfirmCounter = max(tremorConfirmCounter - 1, 0);
  }

  tremorDetected = (tremorConfirmCounter >= TREMOR_CONFIRM_COUNT);

  // Classify intensity
  if (!tremorDetected || gyroMagnitude <= TREMOR_GYRO_THRESHOLD) {
    tremorIntensity = "NONE";
  } else if (gyroMagnitude < TREMOR_MILD_THRESHOLD) {
    tremorIntensity = "MINIMAL";
  } else if (gyroMagnitude < TREMOR_MODERATE_THRESHOLD) {
    tremorIntensity = "MILD";
  } else if (gyroMagnitude < TREMOR_SEVERE_THRESHOLD) {
    tremorIntensity = "MODERATE";
  } else {
    tremorIntensity = "SEVERE";
  }
}

// ════════════════════════════════════════════
//  BUILD JSON PAYLOAD
// ════════════════════════════════════════════
String buildJSON() {
  String json = "{";
  json += "\"tremor\":"     + String(tremorDetected ? "true" : "false") + ",";
  json += "\"intensity\":\"" + tremorIntensity + "\",";
  json += "\"gyroMag\":"    + String(gyroMagnitude, 4) + ",";
  json += "\"motionLevel\":" + String(motionLevel, 4) + ",";
  json += "\"gx\":"         + String(smoothGX, 4) + ",";
  json += "\"gy\":"         + String(smoothGY, 4) + ",";
  json += "\"gz\":"         + String(smoothGZ, 4) + ",";
  json += "\"ax\":"         + String(smoothAX, 4) + ",";
  json += "\"ay\":"         + String(smoothAY, 4) + ",";
  json += "\"az\":"         + String(smoothAZ, 4) + ",";
  json += "\"rssi\":"       + String(WiFi.RSSI()) + ",";
  json += "\"uptime\":"     + String(millis() / 1000);
  json += "}";
  return json;
}

// ════════════════════════════════════════════
//  HTTP HANDLERS
// ════════════════════════════════════════════
void handleCORS() {
  server.sendHeader("Access-Control-Allow-Origin",  "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "Content-Type");
  server.send(204);
}

void handleRoot() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.send(200, "text/plain",
    "Neuro Detect ESP32 Online\n"
    "GET /data  →  live JSON sensor data\n"
    "Open dashboard on your PC/phone browser.");
}

void handleData() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Cache-Control", "no-cache");
  server.send(200, "application/json", buildJSON());
}

// ════════════════════════════════════════════
//  SERIAL MONITOR OUTPUT  (every 500ms)
// ════════════════════════════════════════════
void printSerial() {
  Serial.println("─────────────────────────────────────────────");
  Serial.print("[TREMOR] Status: ");
  Serial.print(tremorDetected ? "YES ⚠️ " : "NO  ✓ ");
  Serial.print(" | Intensity: "); Serial.println(tremorIntensity);

  Serial.print("[GYRO]   Mag="); Serial.print(gyroMagnitude, 3);
  Serial.print("  X=");  Serial.print(smoothGX, 3);
  Serial.print("  Y=");  Serial.print(smoothGY, 3);
  Serial.print("  Z=");  Serial.println(smoothGZ, 3);

  Serial.print("[ACCEL]  X="); Serial.print(smoothAX, 3);
  Serial.print("  Y=");  Serial.print(smoothAY, 3);
  Serial.print("  Z=");  Serial.println(smoothAZ, 3);

  Serial.print("[MOTION] Level="); Serial.println(motionLevel, 3);

  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("[WIFI]   Connected | RSSI=");
    Serial.print(WiFi.RSSI()); Serial.println(" dBm");
  } else {
    Serial.println("[WIFI]   DISCONNECTED");
  }
  Serial.print("[UPTIME] "); Serial.print(millis()/1000); Serial.println("s");
}
